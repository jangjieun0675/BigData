# -*- coding: utf-8 -*-
"""
Created on Wed Mar  9 21:47:33 2022

@author: Park
"""

from lcmlib import lcm 
k=lcm(20,10)
print(k)
